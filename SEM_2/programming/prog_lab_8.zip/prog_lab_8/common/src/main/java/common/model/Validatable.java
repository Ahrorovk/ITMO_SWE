package common.model;

public interface Validatable {
	boolean validate();
  void validation();
}
