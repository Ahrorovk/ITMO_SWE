package common.model;

public enum Difficulty {
    VERY_EASY,
    EASY,
    NORMAL,
    TERRIBLE;
}
