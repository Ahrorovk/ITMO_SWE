package common.dto;

public record SimpleResp  (boolean ok, String message)   {}
