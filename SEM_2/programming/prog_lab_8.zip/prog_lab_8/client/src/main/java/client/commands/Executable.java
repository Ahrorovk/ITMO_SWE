package client.commands;


public interface Executable {
  boolean apply(String[] arguments);
}
